# libft
This is the first 42 project. I've already added ft_printf and get_next_line.
